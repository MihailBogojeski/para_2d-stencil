
void init_rand(double **primary, double **vectors);

void init_file(double **primary, double **vectors);

