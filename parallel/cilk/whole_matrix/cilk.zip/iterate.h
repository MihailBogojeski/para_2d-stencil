void iterate(double **primary, double **vectors);
